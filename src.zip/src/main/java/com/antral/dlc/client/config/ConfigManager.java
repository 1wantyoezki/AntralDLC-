package com.antral.dlc.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("antraldlc.json");

    public static boolean showCoordinates = false;
    public static boolean showServerInfo = false;
    public static boolean compactHud = false;

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;

            JsonObject obj = GSON.fromJson(Files.readString(FILE), JsonObject.class);
            if (obj == null) return;

            showCoordinates = getBool(obj, "showCoordinates", showCoordinates);
            showServerInfo = getBool(obj, "showServerInfo", showServerInfo);
            compactHud = getBool(obj, "compactHud", compactHud);
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());

            JsonObject obj = new JsonObject();
            obj.addProperty("showCoordinates", showCoordinates);
            obj.addProperty("showServerInfo", showServerInfo);
            obj.addProperty("compactHud", compactHud);

            Files.writeString(FILE, GSON.toJson(obj));
        } catch (Exception ignored) {
        }
    }

    private static boolean getBool(JsonObject obj, String key, boolean defaultValue) {
        if (!obj.has(key)) return defaultValue;

        try {
            return obj.get(key).getAsBoolean();
        } catch (Exception ignored) {
            return defaultValue;
        }
    }
}
