package com.antral.dlc.client;

import com.antral.dlc.client.config.ConfigManager;
import com.antral.dlc.client.gui.ClickGUIScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class AntralDLCClient implements ClientModInitializer {
    public static final String MOD_ID = "antraldlc";
    public static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        ConfigManager.load();

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key." + MOD_ID + ".opengui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category." + MOD_ID
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) {
                client.setScreen(new ClickGUIScreen());
            }
        });
    }
}
