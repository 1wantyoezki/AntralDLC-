package com.antral.dlc.client.gui;

import com.antral.dlc.client.config.ConfigManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ClickGUIScreen extends Screen {
    private static final int WIDTH = 190;
    private static final int HEIGHT = 150;
    private static final int RADIUS = 12;
    private static final int ROW_HEIGHT = 28;

    private final String[] names = {
            "Show Coordinates",
            "Show Server Info",
            "Compact HUD"
    };

    public ClickGUIScreen() {
        super(Text.literal("AntralDLC"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int x = (this.width - WIDTH) / 2;
        int y = (this.height - HEIGHT) / 2;

        fillRounded(context, x, y, WIDTH, HEIGHT, RADIUS, 0xFF3A3A3A);
        fillRounded(context, x + 1, y + 1, WIDTH - 2, HEIGHT - 2, RADIUS - 1, 0xD2000000);

        context.drawText(
                this.textRenderer,
                Text.literal("AntralDLC"),
                x + 12,
                y + 10,
                0xFFE0E0E0,
                true
        );

        context.fill(x + 10, y + 28, WIDTH - 20, 1, 0xFF444444);

        int startY = y + 38;

        for (int i = 0; i < names.length; i++) {
            int ry = startY + i * ROW_HEIGHT;

            boolean hover = mouseX >= x + 10
                    && mouseX < x + WIDTH - 10
                    && mouseY >= ry
                    && mouseY < ry + 22;

            fillRounded(
                    context,
                    x + 10,
                    ry,
                    WIDTH - 20,
                    22,
                    6,
                    hover ? 0x40FFFFFF : 0x20FFFFFF
            );

            context.drawText(
                    this.textRenderer,
                    Text.literal(names[i]),
                    x + 18,
                    ry + 7,
                    0xFFDDDDDD,
                    true
            );

            boolean value = get(i);

            int toggleX = x + WIDTH - 42;
            int toggleY = ry + 5;

            fillRounded(
                    context,
                    toggleX,
                    toggleY,
                    28,
                    12,
                    6,
                    value ? 0xFF4CAF50 : 0xFF555555
            );

            int knobX = value ? toggleX + 16 : toggleX + 2;

            fillRounded(
                    context,
                    knobX,
                    toggleY + 2,
                    8,
                    8,
                    4,
                    0xFFFFFFFF
            );
        }

        context.drawText(
                this.textRenderer,
                Text.literal("Right Shift / ESC to close"),
                x + 12,
                y + HEIGHT - 18,
                0xFF888888,
                true
        );
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int x = (this.width - WIDTH) / 2;
            int y = (this.height - HEIGHT) / 2;
            int startY = y + 38;

            for (int i = 0; i < names.length; i++) {
                int ry = startY + i * ROW_HEIGHT;

                if (mouseX >= x + 10
                        && mouseX < x + WIDTH - 10
                        && mouseY >= ry
                        && mouseY < ry + 22) {
                    set(i, !get(i));
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (this.client != null) {
                this.client.setScreen(null);
            }
            return true;
        }

        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private boolean get(int index) {
        return switch (index) {
            case 0 -> ConfigManager.showCoordinates;
            case 1 -> ConfigManager.showServerInfo;
            case 2 -> ConfigManager.compactHud;
            default -> false;
        };
    }

    private void set(int index, boolean value) {
        switch (index) {
            case 0 -> ConfigManager.showCoordinates = value;
            case 1 -> ConfigManager.showServerInfo = value;
            case 2 -> ConfigManager.compactHud = value;
        }

        ConfigManager.save();
    }

    private void fillRounded(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        if (width <= 0 || height <= 0) return;

        int r = Math.max(0, Math.min(radius, Math.min(width / 2, height / 2)));

        for (int row = 0; row < height; row++) {
            int inset = 0;

            if (row < r) {
                int dy = r - row - 1;
                inset = r - (int) Math.sqrt(Math.max(0, r * r - dy * dy));
            } else if (row >= height - r) {
                int dy = row - (height - r);
                inset = r - (int) Math.sqrt(Math.max(0, r * r - dy * dy));
            }

            int fillWidth = width - inset * 2;

            if (fillWidth > 0) {
                context.fill(x + inset, y + row, fillWidth, 1, color);
            }
        }
    }
}
